package fidecompro.exception;

public class EntidadDuplicadaException extends Exception {

    public EntidadDuplicadaException(String msg) {
        super(msg);
    }

}
