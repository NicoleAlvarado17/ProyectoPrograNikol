package fidecompro.exception;

public class StockInsuficienteException extends Exception {

    public StockInsuficienteException(String msg) {
        super(msg);
    }

}
